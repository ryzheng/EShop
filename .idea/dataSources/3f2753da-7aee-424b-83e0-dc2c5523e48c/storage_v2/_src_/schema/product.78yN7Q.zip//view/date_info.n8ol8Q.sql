create view date_info as
select `product`.`product_dynamic`.`pid`       AS `pid`,
       `product`.`product_dynamic`.`psn`       AS `psn`,
       `product`.`product_dynamic`.`make_date` AS `make_date`,
       `product`.`warehouse`.`in_date`         AS `in_date`,
       `product`.`warehouse`.`logistics_date`  AS `logistics_date`,
       `product`.`warehouse`.`out_date`        AS `out_date`,
       `product`.`warehouse`.`location`        AS `location`
from ((`product`.`product_dynamic` left join `product`.`out_list` on ((
    (`product`.`product_dynamic`.`pid` = `product`.`out_list`.`pid`) and
    (`product`.`product_dynamic`.`psn` = `product`.`out_list`.`psn`))))
       left join `product`.`warehouse` on ((`product`.`out_list`.`listid` = `product`.`warehouse`.`out_list`)));

