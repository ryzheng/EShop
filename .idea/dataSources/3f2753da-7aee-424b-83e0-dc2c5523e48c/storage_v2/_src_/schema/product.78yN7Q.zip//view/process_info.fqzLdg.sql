create view process_info as
select `product`.`product_dynamic`.`pid`          AS `pid`,
       `product`.`product_dynamic`.`psn`          AS `psn`,
       `product`.`product_dynamic`.`cid`          AS `cid`,
       `epa`.`ename`                              AS `productor_a`,
       `eia`.`ename`                              AS `inspector_a`,
       `product`.`process_a`.`complete_time`      AS `complete_time_a`,
       `epb`.`ename`                              AS `productor_b`,
       `eib`.`ename`                              AS `inspector_b`,
       `product`.`process_b`.`completeTime`       AS `complete_time_b`,
       `product`.`product_dynamic`.`factory_code` AS `factory_code`,
       `product`.`product_dynamic`.`make_date`    AS `make_date`
from ((((((`product`.`product_dynamic` left join `product`.`process_a` on ((`product`.`product_dynamic`.`process` =
                                                                            `product`.`process_a`.`processid`))) left join `product`.`process_b` on ((
    `product`.`product_dynamic`.`process` =
    `product`.`process_b`.`processid`))) left join `product`.`employee` `epa` on ((`product`.`process_a`.`producerid` = `epa`.`eid`))) left join `product`.`employee` `eia` on ((`eia`.`eid` = `product`.`process_a`.`inspectorid`))) left join `product`.`employee` `epb` on ((`epb`.`eid` = `product`.`process_b`.`producerid`)))
       left join `product`.`employee` `eib` on ((`eib`.`eid` = `product`.`process_b`.`inspectorid`)));

