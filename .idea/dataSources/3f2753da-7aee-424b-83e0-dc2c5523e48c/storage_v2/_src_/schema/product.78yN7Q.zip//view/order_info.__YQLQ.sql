create view order_info as
select `product`.`product_order_list`.`cid`          AS `cid`,
       `product`.`product_order_list`.`pid`          AS `pid`,
       `product`.`product_base`.`pname`              AS `pname`,
       `product`.`product_base`.`image`              AS `image`,
       `product`.`product_order_list`.`pcount`       AS `pcount`,
       `product`.`product_order_list`.`pcount_price` AS `pcount_price`,
       `product`.`product_order_list`.`order_no`     AS `order_no`,
       `product`.`customer_order`.`order_price`      AS `order_price`,
       `product`.`customer_order`.`send_price`       AS `send_price`,
       `product`.`customer_order`.`discounted_price` AS `discounted_price`,
       `product`.`customer_order`.`payable_amount`   AS `payable_amount`,
       `product`.`customer_order`.`payment_amount`   AS `payment_amount`,
       `product`.`customer_order`.`order_status`     AS `order_status`,
       `product`.`customer`.`cname`                  AS `cname`,
       `product`.`customer`.`realname`               AS `realname`,
       `product`.`customer`.`tel`                    AS `tel`,
       `product`.`customer`.`address`                AS `address`
from (((`product`.`customer_order` left join `product`.`product_order_list` on ((
    (`product`.`product_order_list`.`cid` = `product`.`customer_order`.`cid`) and
    (`product`.`product_order_list`.`order_no` =
     `product`.`customer_order`.`order_no`)))) left join `product`.`customer` on ((`product`.`customer`.`cid` = `product`.`product_order_list`.`cid`)))
       left join `product`.`product_base` on ((`product`.`product_order_list`.`pid` = `product`.`product_base`.`pid`)))
order by `product`.`customer_order`.`order_status`;

