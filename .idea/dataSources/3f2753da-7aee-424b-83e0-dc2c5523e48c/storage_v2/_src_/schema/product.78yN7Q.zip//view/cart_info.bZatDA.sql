create view cart_info as
select `product`.`cart`.`pid`           AS `pid`,
       `product`.`cart`.`cid`           AS `cid`,
       `product`.`product_base`.`pname` AS `pname`,
       `product`.`product_base`.`image` AS `image`,
       `product`.`cart`.`total_count`   AS `total_count`,
       `product`.`cart`.`total_price`   AS `total_price`
from (`product`.`cart`
       left join `product`.`product_base` on ((`product`.`cart`.`pid` = `product`.`product_base`.`pid`)));

