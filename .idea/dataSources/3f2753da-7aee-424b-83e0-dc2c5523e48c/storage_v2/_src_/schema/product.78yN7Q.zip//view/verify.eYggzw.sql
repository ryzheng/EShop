create view verify as
select `process_info`.`pid`             AS `pid`,
       `process_info`.`psn`             AS `psn`,
       `process_info`.`cid`             AS `cid`,
       `process_info`.`productor_a`     AS `productor_a`,
       `process_info`.`inspector_a`     AS `inspector_a`,
       `process_info`.`complete_time_a` AS `complete_time_a`,
       `process_info`.`productor_b`     AS `productor_b`,
       `process_info`.`inspector_b`     AS `inspector_b`,
       `process_info`.`complete_time_b` AS `complete_time_b`,
       `date_info`.`in_date`            AS `in_date`,
       `date_info`.`logistics_date`     AS `logistics_date`,
       `date_info`.`location`           AS `location`,
       `process_info`.`factory_code`    AS `factory_code`,
       `process_info`.`make_date`       AS `make_date`
from (`product`.`process_info`
       left join `product`.`date_info`
                 on (((`process_info`.`pid` = `date_info`.`pid`) and (`process_info`.`psn` = `date_info`.`psn`))));

