create view send_info as
select `product`.`product_order_list`.`pid`      AS `pid`,
       `product`.`product_order_list`.`pcount`   AS `pcount`,
       `product`.`product_order_list`.`send_no`  AS `send_no`,
       `product`.`send_list`.`house_location`    AS `send_location`,
       `product`.`send_list`.`add_time`          AS `send_date`,
       `product`.`product_order_list`.`cid`      AS `cid`,
       `product`.`product_order_list`.`order_no` AS `order_no`,
       `product`.`customer`.`cname`              AS `cname`,
       `product`.`customer`.`address`            AS `caddress`
from ((`product`.`send_list` left join `product`.`product_order_list` on ((
    (`product`.`product_order_list`.`send_no` = `product`.`send_list`.`send_no`) and
    (`product`.`product_order_list`.`pid` = `product`.`send_list`.`pid`))))
       left join `product`.`customer` on ((`product`.`product_order_list`.`cid` = `product`.`customer`.`cid`)));

